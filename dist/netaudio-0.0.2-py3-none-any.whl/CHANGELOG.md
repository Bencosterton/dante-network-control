## 0.0.2 (2024-11-18)
### Ben Costerton Update

- Added the deivce handling for 'subscription list' back in
- Removed a fait bit of mDNS output to clean up terminal
- Removed the connection status appended to the end of all subscrition messages
